from datetime import date, datetime

import flet as ft

from models.categoria_model import CategoriaModel
from models.gasto_model import GastoModel


METODOS = ["Efectivo", "Tarjeta", "Transferencia", "Mercado Pago", "Otro"]


def _opcion(valor, texto):
    """Crea una opción compatible con distintas versiones de Flet."""
    try:
        return ft.DropdownOption(key=str(valor), text=str(texto))
    except AttributeError:
        return ft.dropdown.Option(key=str(valor), text=str(texto))


def gastos_view(page, usuario_actual, refrescar):
    uid = usuario_actual["id_usuario"]
    categorias = CategoriaModel.listar()

    descripcion = ft.TextField(label="Descripción", autofocus=True)
    monto = ft.TextField(
        label="Monto",
        keyboard_type=ft.KeyboardType.NUMBER,
        hint_text="Ejemplo: 150.50",
    )
    fecha = ft.TextField(label="Fecha (AAAA-MM-DD)", value=str(date.today()))
    categoria = ft.Dropdown(
        label="Categoría",
        options=[_opcion(c["id_categoria"], c["nombre"]) for c in categorias],
    )
    metodo = ft.Dropdown(
        label="Método de pago",
        value="Efectivo",
        options=[_opcion(x, x) for x in METODOS],
    )
    notas = ft.TextField(label="Notas", multiline=True, min_lines=2, max_lines=3)
    mensaje = ft.Text("", color="#DC2626")
    editando = {"id": None}

    dialogo = ft.AlertDialog(modal=True, title=ft.Text("Nuevo gasto"))

    def mostrar_dialogo(dlg):
        # Compatible con versiones nuevas y anteriores de Flet.
        try:
            page.show_dialog(dlg)
        except (AttributeError, TypeError):
            if dlg not in page.overlay:
                page.overlay.append(dlg)
            dlg.open = True
            page.update()

    def cerrar(e=None):
        dialogo.open = False
        page.update()

    def validar_fecha(valor):
        try:
            return datetime.strptime(valor, "%Y-%m-%d").date()
        except (ValueError, TypeError):
            return None

    def guardar(e):
        mensaje.value = ""
        texto_monto = (monto.value or "").replace("$", "").replace(",", "").strip()
        try:
            valor = float(texto_monto)
        except ValueError:
            valor = 0

        fecha_valida = validar_fecha((fecha.value or "").strip())

        if not (descripcion.value or "").strip():
            mensaje.value = "Escribe una descripción."
        elif valor <= 0:
            mensaje.value = "Escribe un monto mayor que cero."
        elif not categoria.value:
            mensaje.value = "Selecciona una categoría."
        elif not fecha_valida:
            mensaje.value = "La fecha debe tener el formato AAAA-MM-DD."
        else:
            datos = (
                uid,
                int(categoria.value),
                descripcion.value.strip(),
                valor,
                fecha_valida,
                metodo.value or "Efectivo",
                (notas.value or "").strip(),
            )

            if editando["id"] is None:
                ok, respuesta = GastoModel.crear(*datos)
            else:
                ok, respuesta = GastoModel.actualizar(editando["id"], *datos)

            if ok:
                cerrar()
                refrescar("gastos")
                return
            mensaje.value = respuesta

        page.update()

    dialogo.content = ft.Container(
        width=430,
        content=ft.Column(
            tight=True,
            scroll=ft.ScrollMode.AUTO,
            controls=[descripcion, monto, fecha, categoria, metodo, notas, mensaje],
        ),
    )
    dialogo.actions = [
        ft.TextButton("Cancelar", on_click=cerrar),
        ft.FilledButton("Guardar", on_click=guardar),
    ]

    def abrir_nuevo(e=None):
        editando["id"] = None
        dialogo.title = ft.Text("Nuevo gasto")
        descripcion.value = ""
        monto.value = ""
        fecha.value = str(date.today())
        categoria.value = None
        metodo.value = "Efectivo"
        notas.value = ""
        mensaje.value = ""
        mostrar_dialogo(dialogo)

    def abrir_editar(g):
        editando["id"] = g["id_gasto"]
        dialogo.title = ft.Text("Editar gasto")
        descripcion.value = str(g.get("descripcion") or "")
        monto.value = str(g.get("monto") or "")
        fecha.value = str(g.get("fecha") or date.today())
        categoria.value = str(g.get("id_categoria") or "")
        metodo.value = str(g.get("metodo_pago") or "Efectivo")
        notas.value = str(g.get("notas") or "")
        mensaje.value = ""
        mostrar_dialogo(dialogo)

    confirmar = ft.AlertDialog(modal=True, title=ft.Text("Eliminar gasto"))
    eliminar_id = {"id": None}

    def pedir_eliminar(gid):
        eliminar_id["id"] = gid
        confirmar.content = ft.Text(
            "¿Seguro que deseas eliminar este gasto? Esta acción no se puede deshacer."
        )
        mostrar_dialogo(confirmar)

    def cancelar_eliminar(e=None):
        confirmar.open = False
        page.update()

    def eliminar(e=None):
        ok, respuesta = GastoModel.eliminar(eliminar_id["id"], uid)
        confirmar.open = False
        if ok:
            refrescar("gastos")
        else:
            snack = ft.SnackBar(ft.Text(respuesta))
            try:
                page.open(snack)
            except (AttributeError, TypeError):
                page.snack_bar = snack
                snack.open = True
                page.update()

    confirmar.actions = [
        ft.TextButton("Cancelar", on_click=cancelar_eliminar),
        ft.FilledButton("Eliminar", on_click=eliminar),
    ]

    buscar = ft.TextField(
        label="Buscar",
        hint_text="Descripción o notas",
        width=300,
    )
    filtro_categoria = ft.Dropdown(
        label="Categoría",
        width=190,
        value="",
        options=[_opcion("", "Todas")]
        + [_opcion(c["id_categoria"], c["nombre"]) for c in categorias],
    )
    filtro_metodo = ft.Dropdown(
        label="Pago",
        width=180,
        value="",
        options=[_opcion("", "Todos")] + [_opcion(x, x) for x in METODOS],
    )
    orden = ft.Dropdown(
        label="Orden",
        width=180,
        value="reciente",
        options=[
            _opcion("reciente", "Más reciente"),
            _opcion("antiguo", "Más antiguo"),
            _opcion("mayor", "Mayor monto"),
            _opcion("menor", "Menor monto"),
        ],
    )

    lista = ft.Column(spacing=10)
    total_filtrado = ft.Text("", weight=ft.FontWeight.BOLD)
    error_texto = ft.Text("", color="#DC2626")

    def cargar(e=None):
        try:
            categoria_id = int(filtro_categoria.value) if filtro_categoria.value else None
            gastos = GastoModel.listar(
                uid,
                texto=(buscar.value or "").strip(),
                categoria=categoria_id,
                metodo=filtro_metodo.value or None,
                orden=orden.value or "reciente",
            )

            lista.controls.clear()
            error_texto.value = ""
            total = 0.0

            for g in gastos:
                total += float(g.get("monto") or 0)
                detalles = f'{g.get("categoria", "Sin categoría")} · {g.get("fecha", "")} · {g.get("metodo_pago") or "Sin método"}'
                lista.controls.append(
                    ft.Container(
                        padding=15,
                        bgcolor=ft.Colors.WHITE,
                        border_radius=12,
                        border=ft.Border.all(1, "#E5E7EB"),
                        content=ft.Row(
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                ft.Column(
                                    expand=True,
                                    spacing=3,
                                    controls=[
                                        ft.Text(
                                            str(g.get("descripcion") or "Sin descripción"),
                                            weight=ft.FontWeight.BOLD,
                                        ),
                                        ft.Text(detalles, size=12, color="#6B7280"),
                                        ft.Text(
                                            str(g.get("notas") or ""),
                                            size=12,
                                            color="#6B7280",
                                        ),
                                    ],
                                ),
                                ft.Text(
                                    f'${float(g.get("monto") or 0):,.2f}',
                                    color="#DC2626",
                                    weight=ft.FontWeight.BOLD,
                                ),
                                ft.IconButton(
                                    icon=ft.Icons.EDIT_OUTLINED,
                                    tooltip="Editar",
                                    on_click=lambda e, x=g: abrir_editar(x),
                                ),
                                ft.IconButton(
                                    icon=ft.Icons.DELETE_OUTLINE,
                                    icon_color="#DC2626",
                                    tooltip="Eliminar",
                                    on_click=lambda e, gid=g["id_gasto"]: pedir_eliminar(gid),
                                ),
                            ],
                        ),
                    )
                )

            if not gastos:
                lista.controls.append(
                    ft.Container(
                        padding=40,
                        alignment=ft.Alignment.CENTER,
                        content=ft.Text(
                            "No se encontraron gastos.", color="#6B7280"
                        ),
                    )
                )

            total_filtrado.value = f"{len(gastos)} gasto(s) · Total: ${total:,.2f}"
        except Exception as error:
            lista.controls.clear()
            total_filtrado.value = ""
            error_texto.value = f"No se pudieron cargar los gastos: {error}"
            print(f"Error en la vista de gastos: {error}")

        page.update()

    buscar.on_submit = cargar
    filtro_categoria.on_change = cargar
    filtro_metodo.on_change = cargar
    orden.on_change = cargar

    encabezado = ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        controls=[
            ft.Column(
                spacing=2,
                controls=[
                    ft.Text("Gastos", size=30, weight=ft.FontWeight.BOLD),
                    ft.Text(
                        "Agrega, busca, edita y elimina movimientos",
                        color="#6B7280",
                    ),
                ],
            ),
            ft.FilledButton(
                "Nuevo gasto",
                icon=ft.Icons.ADD,
                on_click=abrir_nuevo,
            ),
        ],
    )

    filtros = ft.Row(
        wrap=True,
        spacing=10,
        run_spacing=10,
        controls=[
            buscar,
            filtro_categoria,
            filtro_metodo,
            orden,
            ft.OutlinedButton("Buscar", icon=ft.Icons.SEARCH, on_click=cargar),
        ],
    )

    vista = ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            encabezado,
            filtros,
            total_filtrado,
            error_texto,
            ft.Container(content=lista),
        ],
    )

    # Se carga después de crear toda la vista para evitar un control gris
    # cuando page.update() se ejecuta antes de insertar la vista en la página.
    try:
        categoria_id = int(filtro_categoria.value) if filtro_categoria.value else None
        gastos_iniciales = GastoModel.listar(uid, categoria=categoria_id, orden="reciente")
        total = 0.0
        for g in gastos_iniciales:
            total += float(g.get("monto") or 0)
            detalles = f'{g.get("categoria", "Sin categoría")} · {g.get("fecha", "")} · {g.get("metodo_pago") or "Sin método"}'
            lista.controls.append(
                ft.Container(
                    padding=15,
                    bgcolor=ft.Colors.WHITE,
                    border_radius=12,
                    border=ft.Border.all(1, "#E5E7EB"),
                    content=ft.Row(
                        controls=[
                            ft.Column(
                                expand=True,
                                spacing=3,
                                controls=[
                                    ft.Text(str(g.get("descripcion") or "Sin descripción"), weight=ft.FontWeight.BOLD),
                                    ft.Text(detalles, size=12, color="#6B7280"),
                                    ft.Text(str(g.get("notas") or ""), size=12, color="#6B7280"),
                                ],
                            ),
                            ft.Text(f'${float(g.get("monto") or 0):,.2f}', color="#DC2626", weight=ft.FontWeight.BOLD),
                            ft.IconButton(icon=ft.Icons.EDIT_OUTLINED, tooltip="Editar", on_click=lambda e, x=g: abrir_editar(x)),
                            ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, icon_color="#DC2626", tooltip="Eliminar", on_click=lambda e, gid=g["id_gasto"]: pedir_eliminar(gid)),
                        ]
                    ),
                )
            )
        if not gastos_iniciales:
            lista.controls.append(ft.Container(padding=40, alignment=ft.Alignment.CENTER, content=ft.Text("No se encontraron gastos.", color="#6B7280")))
        total_filtrado.value = f"{len(gastos_iniciales)} gasto(s) · Total: ${total:,.2f}"
    except Exception as error:
        error_texto.value = f"No se pudieron cargar los gastos: {error}"
        print(f"Error inicial en gastos: {error}")

    return vista
