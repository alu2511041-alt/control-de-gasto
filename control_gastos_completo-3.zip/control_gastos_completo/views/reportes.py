from pathlib import Path
from datetime import datetime
import csv
import flet as ft
from openpyxl import Workbook
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from models.gasto_model import GastoModel


def reportes_view(page, usuario_actual):
    uid=usuario_actual["id_usuario"]; resumen=GastoModel.resumen_mes(uid); categorias=GastoModel.por_categoria(uid); metodos=GastoModel.por_metodo(uid); gastos=GastoModel.listar(uid)
    salida=Path(__file__).resolve().parent.parent/"exportaciones"; salida.mkdir(exist_ok=True)
    estado=ft.Text("",color="#16A34A")
    def notificar(ruta): estado.value=f"Archivo creado: {ruta}"; page.update()
    def exportar_excel(e):
        ruta=salida/f"gastos_{datetime.now():%Y%m%d_%H%M%S}.xlsx"; wb=Workbook(); ws=wb.active; ws.title="Gastos"; ws.append(["Fecha","Descripción","Categoría","Método","Monto","Notas"])
        for g in gastos: ws.append([str(g["fecha"]),g["descripcion"],g["categoria"],g["metodo_pago"],float(g["monto"]),g["notas"] or ""])
        ws.column_dimensions["A"].width=14; ws.column_dimensions["B"].width=28; ws.column_dimensions["C"].width=18; ws.column_dimensions["D"].width=18; ws.column_dimensions["E"].width=14; ws.column_dimensions["F"].width=35; wb.save(ruta); notificar(ruta)
    def exportar_csv(e):
        ruta=salida/f"gastos_{datetime.now():%Y%m%d_%H%M%S}.csv"
        with ruta.open("w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f); w.writerow(["Fecha","Descripción","Categoría","Método","Monto","Notas"])
            for g in gastos: w.writerow([g["fecha"],g["descripcion"],g["categoria"],g["metodo_pago"],g["monto"],g["notas"] or ""])
        notificar(ruta)
    def exportar_pdf(e):
        ruta=salida/f"reporte_{datetime.now():%Y%m%d_%H%M%S}.pdf"; c=canvas.Canvas(str(ruta),pagesize=letter); y=750; c.setFont("Helvetica-Bold",18); c.drawString(50,y,"Reporte de gastos"); y-=30; c.setFont("Helvetica",11); c.drawString(50,y,f'Total del mes: ${resumen["total"]:,.2f}'); y-=18; c.drawString(50,y,f'Número de gastos: {resumen["cantidad"]}'); y-=30
        for g in gastos:
            if y<70: c.showPage(); y=750
            c.drawString(50,y,f'{g["fecha"]} - {g["descripcion"]} - {g["categoria"]} - ${float(g["monto"]):,.2f}'); y-=18
        c.save(); notificar(ruta)
    def tabla(datos, campo):
        controles=[]
        for d in datos: controles.append(ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[ft.Text(str(d[campo])),ft.Text(f'${float(d["total"]):,.2f}',weight=ft.FontWeight.BOLD)]))
        return controles or [ft.Text("Sin datos",color="#6B7280")]
    return ft.Column(expand=True,scroll=ft.ScrollMode.AUTO,controls=[ft.Text("Reportes",size=30,weight=ft.FontWeight.BOLD),ft.Text("Estadísticas y exportación de movimientos",color="#6B7280"),ft.Row(wrap=True,controls=[ft.FilledButton(content=ft.Text("Exportar Excel"),on_click=exportar_excel),ft.OutlinedButton(content=ft.Text("Exportar PDF"),on_click=exportar_pdf),ft.OutlinedButton(content=ft.Text("Exportar CSV"),on_click=exportar_csv)]),estado,ft.Row(wrap=True,spacing=16,run_spacing=16,controls=[ft.Container(width=390,padding=20,bgcolor=ft.Colors.WHITE,border_radius=16,border=ft.Border.all(1,"#E5E7EB"),content=ft.Column(controls=[ft.Text("Resumen mensual",size=20,weight=ft.FontWeight.BOLD),ft.Text(f'Total: ${resumen["total"]:,.2f}',size=22),ft.Text(f'Gasto mayor: ${resumen["mayor"]:,.2f}'),ft.Text(f'Promedio: ${resumen["promedio"]:,.2f}'),ft.Text(f'Número de gastos: {resumen["cantidad"]}')])),ft.Container(width=390,padding=20,bgcolor=ft.Colors.WHITE,border_radius=16,border=ft.Border.all(1,"#E5E7EB"),content=ft.Column(controls=[ft.Text("Por categoría",size=20,weight=ft.FontWeight.BOLD),*tabla(categorias,"nombre")])),ft.Container(width=390,padding=20,bgcolor=ft.Colors.WHITE,border_radius=16,border=ft.Border.all(1,"#E5E7EB"),content=ft.Column(controls=[ft.Text("Por método de pago",size=20,weight=ft.FontWeight.BOLD),*tabla(metodos,"metodo")]))])])
