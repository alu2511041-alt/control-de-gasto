import flet as ft
from models.gasto_model import GastoModel
from models.presupuesto_model import PresupuestoModel


def _tarjeta(titulo, valor, icono, subtitulo=""):
    return ft.Container(width=230,height=145,padding=20,bgcolor=ft.Colors.WHITE,border_radius=16,border=ft.Border.all(1,"#E5E7EB"),content=ft.Column(controls=[ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[ft.Text(titulo,color="#6B7280"),ft.Icon(icono,color="#2563EB")]),ft.Text(valor,size=25,weight=ft.FontWeight.BOLD),ft.Text(subtitulo,size=11,color="#6B7280")]))


def dashboard_view(page, usuario_actual):
    uid=usuario_actual["id_usuario"]; r=GastoModel.resumen_mes(uid); presupuesto=PresupuestoModel.obtener_actual(uid); disponible=presupuesto-r["total"]; progreso=min(r["total"]/presupuesto,1) if presupuesto else 0
    filas=[]
    for g in GastoModel.listar(uid,limite=5):
        filas.append(ft.Container(padding=12,border=ft.Border(bottom=ft.BorderSide(1,"#E5E7EB")),content=ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,controls=[ft.Column(spacing=1,controls=[ft.Text(g["descripcion"],weight=ft.FontWeight.BOLD),ft.Text(f'{g["categoria"]} · {g["fecha"]}',size=12,color="#6B7280")]),ft.Text(f'${float(g["monto"]):,.2f}',color="#DC2626",weight=ft.FontWeight.BOLD)])))
    if not filas: filas=[ft.Container(padding=40,alignment=ft.Alignment.CENTER,content=ft.Text("Todavía no hay gastos registrados.",color="#6B7280"))]
    alerta="Define tu presupuesto mensual." if presupuesto<=0 else ("Presupuesto agotado o excedido." if disponible<0 else ("Has utilizado más del 80% del presupuesto." if progreso>=.8 else "Tu presupuesto está bajo control."))
    return ft.Column(expand=True,scroll=ft.ScrollMode.AUTO,controls=[ft.Text("Dashboard",size=30,weight=ft.FontWeight.BOLD),ft.Text("Resumen del mes actual",color="#6B7280"),ft.Container(padding=14,bgcolor="#EFF6FF",border_radius=12,content=ft.Row(controls=[ft.Icon(ft.Icons.INFO_OUTLINE,color="#2563EB"),ft.Text(alerta)])),ft.Row(wrap=True,spacing=15,run_spacing=15,controls=[_tarjeta("Total gastado",f'${r["total"]:,.2f}',ft.Icons.PAYMENTS),_tarjeta("Presupuesto",f'${presupuesto:,.2f}',ft.Icons.ACCOUNT_BALANCE_WALLET),_tarjeta("Disponible",f'${disponible:,.2f}',ft.Icons.SAVINGS),_tarjeta("Gastos",str(r["cantidad"]),ft.Icons.RECEIPT_LONG),_tarjeta("Promedio",f'${r["promedio"]:,.2f}',ft.Icons.QUERY_STATS),_tarjeta("Categoría principal",r["categoria_top"],ft.Icons.CATEGORY)]),ft.Container(padding=20,bgcolor=ft.Colors.WHITE,border_radius=16,border=ft.Border.all(1,"#E5E7EB"),content=ft.Column(controls=[ft.Text("Uso del presupuesto",size=18,weight=ft.FontWeight.BOLD),ft.ProgressBar(value=progreso,height=12),ft.Text(f"{progreso*100:.1f}% utilizado",color="#6B7280")])),ft.Container(padding=20,bgcolor=ft.Colors.WHITE,border_radius=16,border=ft.Border.all(1,"#E5E7EB"),content=ft.Column(controls=[ft.Text("Últimos gastos",size=20,weight=ft.FontWeight.BOLD),*filas]))])
