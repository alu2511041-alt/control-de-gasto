import mysql.connector
from database.conexion import ConexionBD


class GastoModel:
    @staticmethod
    def crear(id_usuario, id_categoria, descripcion, monto, fecha, metodo_pago, notas):
        return GastoModel._guardar(None, id_usuario, id_categoria, descripcion, monto, fecha, metodo_pago, notas)

    @staticmethod
    def actualizar(id_gasto, id_usuario, id_categoria, descripcion, monto, fecha, metodo_pago, notas):
        return GastoModel._guardar(id_gasto, id_usuario, id_categoria, descripcion, monto, fecha, metodo_pago, notas)

    @staticmethod
    def _guardar(id_gasto, id_usuario, id_categoria, descripcion, monto, fecha, metodo_pago, notas):
        conexion = cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return False, "No se pudo conectar con MySQL."
            cursor = conexion.cursor()
            if id_gasto is None:
                cursor.execute(
                    """INSERT INTO gastos
                    (id_usuario,id_categoria,descripcion,monto,fecha,metodo_pago,notas)
                    VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                    (id_usuario,id_categoria,descripcion,monto,fecha,metodo_pago,notas or None),
                )
                mensaje = "Gasto guardado correctamente."
            else:
                cursor.execute(
                    """UPDATE gastos SET id_categoria=%s, descripcion=%s, monto=%s,
                    fecha=%s, metodo_pago=%s, notas=%s
                    WHERE id_gasto=%s AND id_usuario=%s""",
                    (id_categoria,descripcion,monto,fecha,metodo_pago,notas or None,id_gasto,id_usuario),
                )
                if cursor.rowcount == 0:
                    return False, "No se encontró el gasto."
                mensaje = "Gasto actualizado correctamente."
            conexion.commit()
            return True, mensaje
        except mysql.connector.Error as error:
            return False, f"Error de MySQL: {error}"
        finally:
            if cursor is not None: cursor.close()
            if conexion is not None and conexion.is_connected(): conexion.close()

    @staticmethod
    def listar(id_usuario, limite=None, texto="", categoria=None, metodo=None, desde=None, hasta=None, orden="reciente"):
        conexion = cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None: return []
            cursor = conexion.cursor(dictionary=True)
            consulta = """SELECT g.id_gasto,g.id_categoria,g.descripcion,g.monto,g.fecha,
            g.metodo_pago,g.notas,c.nombre AS categoria
            FROM gastos g INNER JOIN categorias c ON c.id_categoria=g.id_categoria
            WHERE g.id_usuario=%s"""
            parametros = [id_usuario]
            if texto:
                consulta += " AND (g.descripcion LIKE %s OR g.notas LIKE %s)"
                patron = f"%{texto}%"
                parametros += [patron, patron]
            if categoria:
                consulta += " AND g.id_categoria=%s"; parametros.append(categoria)
            if metodo:
                consulta += " AND g.metodo_pago=%s"; parametros.append(metodo)
            if desde:
                consulta += " AND g.fecha >= %s"; parametros.append(desde)
            if hasta:
                consulta += " AND g.fecha <= %s"; parametros.append(hasta)
            ordenes = {
                "reciente": "g.fecha DESC, g.id_gasto DESC",
                "antiguo": "g.fecha ASC, g.id_gasto ASC",
                "mayor": "g.monto DESC",
                "menor": "g.monto ASC",
            }
            consulta += " ORDER BY " + ordenes.get(orden, ordenes["reciente"])
            if limite is not None:
                consulta += " LIMIT %s"; parametros.append(limite)
            cursor.execute(consulta, tuple(parametros))
            return cursor.fetchall()
        except mysql.connector.Error as error:
            print(f"Error al listar gastos: {error}"); return []
        finally:
            if cursor is not None: cursor.close()
            if conexion is not None and conexion.is_connected(): conexion.close()

    @staticmethod
    def eliminar(id_gasto, id_usuario):
        conexion = cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None: return False, "No se pudo conectar con MySQL."
            cursor = conexion.cursor()
            cursor.execute("DELETE FROM gastos WHERE id_gasto=%s AND id_usuario=%s", (id_gasto,id_usuario))
            conexion.commit()
            return (cursor.rowcount > 0, "Gasto eliminado." if cursor.rowcount else "No se encontró el gasto.")
        except mysql.connector.Error as error:
            return False, f"Error de MySQL: {error}"
        finally:
            if cursor is not None: cursor.close()
            if conexion is not None and conexion.is_connected(): conexion.close()

    @staticmethod
    def resumen_mes(id_usuario):
        conexion = cursor = None
        vacio = {"total":0.0,"cantidad":0,"mayor":0.0,"promedio":0.0,"categoria_top":"Sin datos"}
        try:
            conexion = ConexionBD.conectar()
            if conexion is None: return vacio
            cursor = conexion.cursor(dictionary=True)
            cursor.execute("""SELECT COALESCE(SUM(monto),0) total,COUNT(*) cantidad,
            COALESCE(MAX(monto),0) mayor,COALESCE(AVG(monto),0) promedio
            FROM gastos WHERE id_usuario=%s AND MONTH(fecha)=MONTH(CURDATE())
            AND YEAR(fecha)=YEAR(CURDATE())""", (id_usuario,))
            d = cursor.fetchone()
            cursor.execute("""SELECT c.nombre, SUM(g.monto) total FROM gastos g
            JOIN categorias c ON c.id_categoria=g.id_categoria
            WHERE g.id_usuario=%s AND MONTH(g.fecha)=MONTH(CURDATE())
            AND YEAR(g.fecha)=YEAR(CURDATE()) GROUP BY c.id_categoria,c.nombre
            ORDER BY total DESC LIMIT 1""", (id_usuario,))
            top = cursor.fetchone()
            return {"total":float(d["total"] or 0),"cantidad":int(d["cantidad"] or 0),
                    "mayor":float(d["mayor"] or 0),"promedio":float(d["promedio"] or 0),
                    "categoria_top": top["nombre"] if top else "Sin datos"}
        except mysql.connector.Error as error:
            print(f"Error al obtener resumen: {error}"); return vacio
        finally:
            if cursor is not None: cursor.close()
            if conexion is not None and conexion.is_connected(): conexion.close()

    @staticmethod
    def por_categoria(id_usuario):
        conexion = cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None: return []
            cursor = conexion.cursor(dictionary=True)
            cursor.execute("""SELECT c.nombre,COUNT(*) cantidad,SUM(g.monto) total
            FROM gastos g JOIN categorias c ON c.id_categoria=g.id_categoria
            WHERE g.id_usuario=%s AND MONTH(g.fecha)=MONTH(CURDATE())
            AND YEAR(g.fecha)=YEAR(CURDATE()) GROUP BY c.id_categoria,c.nombre ORDER BY total DESC""", (id_usuario,))
            return cursor.fetchall()
        except mysql.connector.Error as error:
            print(error); return []
        finally:
            if cursor is not None: cursor.close()
            if conexion is not None and conexion.is_connected(): conexion.close()

    @staticmethod
    def por_metodo(id_usuario):
        conexion = cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None: return []
            cursor = conexion.cursor(dictionary=True)
            cursor.execute("""SELECT COALESCE(metodo_pago,'Sin especificar') metodo, COUNT(*) cantidad, SUM(monto) total
            FROM gastos WHERE id_usuario=%s AND MONTH(fecha)=MONTH(CURDATE())
            AND YEAR(fecha)=YEAR(CURDATE()) GROUP BY metodo_pago ORDER BY total DESC""", (id_usuario,))
            return cursor.fetchall()
        except mysql.connector.Error as error:
            print(error); return []
        finally:
            if cursor is not None: cursor.close()
            if conexion is not None and conexion.is_connected(): conexion.close()
