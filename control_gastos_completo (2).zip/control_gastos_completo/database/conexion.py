import mysql.connector
from mysql.connector import Error

from config import DB_CONFIG


class ConexionBD:
    @staticmethod
    def conectar():
        try:
            return mysql.connector.connect(**DB_CONFIG)
        except Error as error:
            print(f"Error de conexión con MySQL: {error}")
            return None
