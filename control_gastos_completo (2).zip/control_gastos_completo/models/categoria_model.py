import mysql.connector

from database.conexion import ConexionBD


class CategoriaModel:
    @staticmethod
    def listar():
        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return []

            cursor = conexion.cursor(dictionary=True)
            cursor.execute(
                """
                SELECT id_categoria, nombre, icono, color
                FROM categorias
                WHERE activa = 1
                ORDER BY nombre
                """
            )
            return cursor.fetchall()
        except mysql.connector.Error as error:
            print(f"Error al listar categorías: {error}")
            return []
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()
