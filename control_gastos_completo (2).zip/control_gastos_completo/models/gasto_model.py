import mysql.connector
from datetime import date

from database.conexion import ConexionBD


class GastoModel:
    @staticmethod
    def crear(id_usuario, id_categoria, descripcion, monto, fecha, metodo_pago, notas):
        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return False, "No se pudo conectar con MySQL."

            cursor = conexion.cursor()
            cursor.execute(
                """
                INSERT INTO gastos
                    (id_usuario, id_categoria, descripcion, monto, fecha,
                     metodo_pago, notas)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    id_usuario,
                    id_categoria,
                    descripcion,
                    monto,
                    fecha,
                    metodo_pago,
                    notas or None,
                ),
            )
            conexion.commit()
            return True, "Gasto guardado correctamente."
        except mysql.connector.Error as error:
            return False, f"Error de MySQL: {error}"
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()

    @staticmethod
    def listar(id_usuario, limite=None):
        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return []

            cursor = conexion.cursor(dictionary=True)
            consulta = """
                SELECT
                    g.id_gasto,
                    g.descripcion,
                    g.monto,
                    g.fecha,
                    g.metodo_pago,
                    g.notas,
                    c.nombre AS categoria
                FROM gastos g
                INNER JOIN categorias c
                    ON c.id_categoria = g.id_categoria
                WHERE g.id_usuario = %s
                ORDER BY g.fecha DESC, g.id_gasto DESC
            """
            parametros = [id_usuario]
            if limite is not None:
                consulta += " LIMIT %s"
                parametros.append(limite)

            cursor.execute(consulta, tuple(parametros))
            return cursor.fetchall()
        except mysql.connector.Error as error:
            print(f"Error al listar gastos: {error}")
            return []
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()

    @staticmethod
    def eliminar(id_gasto, id_usuario):
        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return False, "No se pudo conectar con MySQL."

            cursor = conexion.cursor()
            cursor.execute(
                """
                DELETE FROM gastos
                WHERE id_gasto = %s AND id_usuario = %s
                """,
                (id_gasto, id_usuario),
            )
            conexion.commit()
            if cursor.rowcount == 0:
                return False, "El gasto no existe o no pertenece al usuario."
            return True, "Gasto eliminado."
        except mysql.connector.Error as error:
            return False, f"Error de MySQL: {error}"
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()

    @staticmethod
    def resumen_mes(id_usuario):
        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return {"total": 0.0, "cantidad": 0, "mayor": 0.0, "promedio": 0.0}

            cursor = conexion.cursor(dictionary=True)
            cursor.execute(
                """
                SELECT
                    COALESCE(SUM(monto), 0) AS total,
                    COUNT(*) AS cantidad,
                    COALESCE(MAX(monto), 0) AS mayor,
                    COALESCE(AVG(monto), 0) AS promedio
                FROM gastos
                WHERE id_usuario = %s
                  AND MONTH(fecha) = MONTH(CURDATE())
                  AND YEAR(fecha) = YEAR(CURDATE())
                """,
                (id_usuario,),
            )
            datos = cursor.fetchone()
            return {
                "total": float(datos["total"] or 0),
                "cantidad": int(datos["cantidad"] or 0),
                "mayor": float(datos["mayor"] or 0),
                "promedio": float(datos["promedio"] or 0),
            }
        except mysql.connector.Error as error:
            print(f"Error al obtener resumen: {error}")
            return {"total": 0.0, "cantidad": 0, "mayor": 0.0, "promedio": 0.0}
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()
