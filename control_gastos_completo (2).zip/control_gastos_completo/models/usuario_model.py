import bcrypt
import mysql.connector

from database.conexion import ConexionBD


class UsuarioModel:
    @staticmethod
    def registrar(nombre, usuario, correo, contrasena):
        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return False, "No se pudo conectar con MySQL."

            cursor = conexion.cursor()
            cursor.execute(
                """
                SELECT id_usuario
                FROM usuarios
                WHERE usuario = %s OR correo = %s
                LIMIT 1
                """,
                (usuario, correo),
            )
            if cursor.fetchone():
                return False, "El usuario o correo ya está registrado."

            hash_password = bcrypt.hashpw(
                contrasena.encode("utf-8"), bcrypt.gensalt()
            ).decode("utf-8")

            cursor.execute(
                """
                INSERT INTO usuarios
                    (nombre, usuario, correo, contrasena, activo)
                VALUES (%s, %s, %s, %s, 1)
                """,
                (nombre, usuario, correo, hash_password),
            )
            conexion.commit()
            return True, "Usuario registrado correctamente."
        except mysql.connector.Error as error:
            return False, f"Error de MySQL: {error}"
        except Exception as error:
            return False, f"Error: {error}"
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()

    @staticmethod
    def iniciar_sesion(identificador, contrasena):
        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return False, "No se pudo conectar con MySQL.", None

            cursor = conexion.cursor(dictionary=True)
            cursor.execute(
                """
                SELECT id_usuario, nombre, usuario, correo, contrasena, activo
                FROM usuarios
                WHERE usuario = %s OR correo = %s
                LIMIT 1
                """,
                (identificador, identificador),
            )
            datos = cursor.fetchone()

            if datos is None:
                return False, "Usuario o correo no registrado.", None
            if not datos["activo"]:
                return False, "La cuenta está desactivada.", None

            if not bcrypt.checkpw(
                contrasena.encode("utf-8"),
                datos["contrasena"].encode("utf-8"),
            ):
                return False, "Contraseña incorrecta.", None

            datos.pop("contrasena", None)
            return True, "Inicio de sesión correcto.", datos
        except mysql.connector.Error as error:
            return False, f"Error de MySQL: {error}", None
        except Exception as error:
            return False, f"Error: {error}", None
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()
