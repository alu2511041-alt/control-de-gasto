import mysql.connector
from datetime import datetime

from database.conexion import ConexionBD


class PresupuestoModel:
    @staticmethod
    def guardar(id_usuario, monto, mes=None, anio=None):
        ahora = datetime.now()
        mes = mes or ahora.month
        anio = anio or ahora.year

        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return False, "No se pudo conectar con MySQL."

            cursor = conexion.cursor()
            cursor.execute(
                """
                SELECT id_presupuesto
                FROM presupuestos
                WHERE id_usuario = %s AND mes = %s AND anio = %s
                LIMIT 1
                """,
                (id_usuario, mes, anio),
            )
            existente = cursor.fetchone()

            if existente:
                cursor.execute(
                    """
                    UPDATE presupuestos
                    SET monto = %s
                    WHERE id_presupuesto = %s
                    """,
                    (monto, existente[0]),
                )
            else:
                cursor.execute(
                    """
                    INSERT INTO presupuestos
                        (id_usuario, monto, mes, anio)
                    VALUES (%s, %s, %s, %s)
                    """,
                    (id_usuario, monto, mes, anio),
                )

            conexion.commit()
            return True, "Presupuesto guardado correctamente."
        except mysql.connector.Error as error:
            return False, f"Error de MySQL: {error}"
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()

    @staticmethod
    def obtener_actual(id_usuario):
        conexion = None
        cursor = None
        try:
            conexion = ConexionBD.conectar()
            if conexion is None:
                return 0.0

            cursor = conexion.cursor()
            cursor.execute(
                """
                SELECT monto
                FROM presupuestos
                WHERE id_usuario = %s
                  AND mes = MONTH(CURDATE())
                  AND anio = YEAR(CURDATE())
                LIMIT 1
                """,
                (id_usuario,),
            )
            fila = cursor.fetchone()
            return float(fila[0]) if fila else 0.0
        except mysql.connector.Error as error:
            print(f"Error al obtener presupuesto: {error}")
            return 0.0
        finally:
            if cursor is not None:
                cursor.close()
            if conexion is not None and conexion.is_connected():
                conexion.close()
