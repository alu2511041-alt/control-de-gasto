DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "messi123",
    "database": "control_gastos2",
}
