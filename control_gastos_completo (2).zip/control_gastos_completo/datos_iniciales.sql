USE control_gastos2;

INSERT INTO categorias (nombre, icono, color, activa)
SELECT 'Alimentos', 'restaurant', '#F59E0B', 1
WHERE NOT EXISTS (
    SELECT 1 FROM categorias WHERE nombre = 'Alimentos'
);

INSERT INTO categorias (nombre, icono, color, activa)
SELECT 'Transporte', 'directions_car', '#2563EB', 1
WHERE NOT EXISTS (
    SELECT 1 FROM categorias WHERE nombre = 'Transporte'
);

INSERT INTO categorias (nombre, icono, color, activa)
SELECT 'Servicios', 'receipt_long', '#7C3AED', 1
WHERE NOT EXISTS (
    SELECT 1 FROM categorias WHERE nombre = 'Servicios'
);

INSERT INTO categorias (nombre, icono, color, activa)
SELECT 'Salud', 'medical_services', '#DC2626', 1
WHERE NOT EXISTS (
    SELECT 1 FROM categorias WHERE nombre = 'Salud'
);

INSERT INTO categorias (nombre, icono, color, activa)
SELECT 'Entretenimiento', 'movie', '#DB2777', 1
WHERE NOT EXISTS (
    SELECT 1 FROM categorias WHERE nombre = 'Entretenimiento'
);

INSERT INTO categorias (nombre, icono, color, activa)
SELECT 'Otros', 'category', '#6B7280', 1
WHERE NOT EXISTS (
    SELECT 1 FROM categorias WHERE nombre = 'Otros'
);
