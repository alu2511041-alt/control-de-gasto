import flet as ft

from models.gasto_model import GastoModel
from models.presupuesto_model import PresupuestoModel


def presupuesto_view(page, usuario_actual, refrescar):
    uid = usuario_actual["id_usuario"]
    actual = PresupuestoModel.obtener_actual(uid)
    gastado = GastoModel.resumen_mes(uid)["total"]
    disponible = actual - gastado
    progreso = min(gastado / actual, 1.0) if actual > 0 else 0.0

    campo = ft.TextField(
        label="Presupuesto mensual",
        hint_text="Ejemplo: 5000",
        keyboard_type=ft.KeyboardType.NUMBER,
        prefix=ft.Text("$"),
        value=str(actual) if actual > 0 else "",
    )
    mensaje = ft.Text("")

    def guardar(e):
        try:
            monto = float((campo.value or "").replace(",", "").strip())
        except ValueError:
            mensaje.value = "Escribe un monto válido."
            mensaje.color = "#DC2626"
            page.update()
            return

        if monto <= 0:
            mensaje.value = "El presupuesto debe ser mayor que cero."
            mensaje.color = "#DC2626"
            page.update()
            return

        ok, respuesta = PresupuestoModel.guardar(uid, monto)
        mensaje.value = respuesta
        mensaje.color = "#16A34A" if ok else "#DC2626"
        page.update()
        if ok:
            refrescar("presupuesto")

    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Text("Presupuesto", size=30, weight=ft.FontWeight.BOLD),
            ft.Text("Presupuesto del mes actual", color="#6B7280"),
            ft.Row(
                wrap=True,
                spacing=16,
                run_spacing=16,
                controls=[
                    ft.Container(
                        width=360,
                        padding=25,
                        bgcolor=ft.Colors.WHITE,
                        border_radius=16,
                        border=ft.Border.all(1, "#E5E7EB"),
                        content=ft.Column(
                            controls=[
                                ft.Text("Definir presupuesto", size=20,
                                        weight=ft.FontWeight.BOLD),
                                campo,
                                mensaje,
                                ft.FilledButton(
                                    content=ft.Text("Guardar presupuesto"),
                                    on_click=guardar,
                                ),
                            ],
                        ),
                    ),
                    ft.Container(
                        width=500,
                        padding=25,
                        bgcolor=ft.Colors.WHITE,
                        border_radius=16,
                        border=ft.Border.all(1, "#E5E7EB"),
                        content=ft.Column(
                            controls=[
                                ft.Text("Resumen", size=20,
                                        weight=ft.FontWeight.BOLD),
                                ft.Text(f"Presupuesto: ${actual:,.2f}", size=22),
                                ft.Text(f"Gastado: ${gastado:,.2f}",
                                        color="#DC2626"),
                                ft.Text(f"Disponible: ${disponible:,.2f}",
                                        color="#16A34A"),
                                ft.ProgressBar(value=progreso, height=12),
                                ft.Text(f"{progreso * 100:.1f}% utilizado",
                                        color="#6B7280"),
                            ],
                        ),
                    ),
                ],
            ),
        ],
    )
