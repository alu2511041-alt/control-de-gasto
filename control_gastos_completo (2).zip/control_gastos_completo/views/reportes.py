import flet as ft

from models.gasto_model import GastoModel


def reportes_view(page, usuario_actual):
    resumen = GastoModel.resumen_mes(usuario_actual["id_usuario"])
    return ft.Column(
        expand=True,
        controls=[
            ft.Text("Reportes", size=30, weight=ft.FontWeight.BOLD),
            ft.Text("Resumen financiero del mes", color="#6B7280"),
            ft.Container(
                width=500,
                padding=25,
                bgcolor=ft.Colors.WHITE,
                border_radius=16,
                border=ft.Border.all(1, "#E5E7EB"),
                content=ft.Column(
                    controls=[
                        ft.Text(f'Total: ${resumen["total"]:,.2f}', size=22),
                        ft.Text(f'Gasto mayor: ${resumen["mayor"]:,.2f}'),
                        ft.Text(f'Promedio: ${resumen["promedio"]:,.2f}'),
                        ft.Text(f'Número de gastos: {resumen["cantidad"]}'),
                    ],
                ),
            ),
        ],
    )
