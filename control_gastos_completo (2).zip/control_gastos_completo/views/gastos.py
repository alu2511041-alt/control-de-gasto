from datetime import date
import flet as ft

from models.categoria_model import CategoriaModel
from models.gasto_model import GastoModel


def gastos_view(page, usuario_actual, refrescar):
    uid = usuario_actual["id_usuario"]
    categorias = CategoriaModel.listar()

    descripcion = ft.TextField(label="Descripción")
    monto = ft.TextField(label="Monto", keyboard_type=ft.KeyboardType.NUMBER,
                         prefix=ft.Text("$"))
    categoria = ft.Dropdown(
        label="Categoría",
        options=[
            ft.DropdownOption(key=str(c["id_categoria"]), text=c["nombre"])
            for c in categorias
        ],
    )
    metodo = ft.Dropdown(
        label="Método de pago",
        value="Efectivo",
        options=[
            ft.DropdownOption(key="Efectivo", text="Efectivo"),
            ft.DropdownOption(key="Tarjeta", text="Tarjeta"),
            ft.DropdownOption(key="Transferencia", text="Transferencia"),
            ft.DropdownOption(key="Otro", text="Otro"),
        ],
    )
    notas = ft.TextField(label="Notas", multiline=True, min_lines=2, max_lines=3)
    mensaje = ft.Text("", color="#DC2626")

    dialogo = ft.AlertDialog(modal=True, title=ft.Text("Nuevo gasto"))

    def cerrar(e=None):
        dialogo.open = False
        page.update()

    def guardar(e):
        try:
            valor = float((monto.value or "").replace(",", "").strip())
        except ValueError:
            mensaje.value = "Escribe un monto válido."
            page.update()
            return

        if not (descripcion.value or "").strip():
            mensaje.value = "Escribe una descripción."
            page.update()
            return
        if not categoria.value:
            mensaje.value = "Selecciona una categoría."
            page.update()
            return
        if valor <= 0:
            mensaje.value = "El monto debe ser mayor que cero."
            page.update()
            return

        ok, respuesta = GastoModel.crear(
            uid,
            int(categoria.value),
            descripcion.value.strip(),
            valor,
            date.today(),
            metodo.value,
            (notas.value or "").strip(),
        )
        if ok:
            cerrar()
            refrescar("gastos")
        else:
            mensaje.value = respuesta
            page.update()

    dialogo.content = ft.Container(
        width=420,
        content=ft.Column(
            tight=True,
            controls=[descripcion, monto, categoria, metodo, notas, mensaje],
        ),
    )
    dialogo.actions = [
        ft.TextButton(content=ft.Text("Cancelar"), on_click=cerrar),
        ft.FilledButton(content=ft.Text("Guardar"), on_click=guardar),
    ]

    def abrir(e):
        mensaje.value = ""
        page.show_dialog(dialogo)

    def eliminar(id_gasto):
        ok, _ = GastoModel.eliminar(id_gasto, uid)
        if ok:
            refrescar("gastos")

    gastos = GastoModel.listar(uid)
    controles = []
    for gasto in gastos:
        controles.append(
            ft.Container(
                padding=15,
                bgcolor=ft.Colors.WHITE,
                border_radius=12,
                border=ft.Border.all(1, "#E5E7EB"),
                content=ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Column(
                            expand=True,
                            spacing=2,
                            controls=[
                                ft.Text(gasto["descripcion"],
                                        weight=ft.FontWeight.BOLD),
                                ft.Text(
                                    f'{gasto["categoria"]} · {gasto["fecha"]} · '
                                    f'{gasto["metodo_pago"]}',
                                    size=12,
                                    color="#6B7280",
                                ),
                            ],
                        ),
                        ft.Text(f'${float(gasto["monto"]):,.2f}',
                                color="#DC2626",
                                weight=ft.FontWeight.BOLD),
                        ft.IconButton(
                            icon=ft.Icons.DELETE_OUTLINE,
                            icon_color="#DC2626",
                            tooltip="Eliminar",
                            on_click=lambda e, gid=gasto["id_gasto"]: eliminar(gid),
                        ),
                    ],
                ),
            )
        )

    if not controles:
        controles.append(
            ft.Container(
                padding=50,
                alignment=ft.Alignment.CENTER,
                content=ft.Text("No hay gastos registrados.", color="#6B7280"),
            )
        )

    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    ft.Column(
                        spacing=2,
                        controls=[
                            ft.Text("Gastos", size=30,
                                    weight=ft.FontWeight.BOLD),
                            ft.Text("Movimientos guardados en MySQL",
                                    color="#6B7280"),
                        ],
                    ),
                    ft.FilledButton(
                        content=ft.Row(
                            tight=True,
                            controls=[ft.Icon(ft.Icons.ADD),
                                      ft.Text("Nuevo gasto")],
                        ),
                        on_click=abrir,
                    ),
                ],
            ),
            *controles,
        ],
    )
