import re
import flet as ft

from models.usuario_model import UsuarioModel


def registro_view(page, mostrar_login):
    mensaje = ft.Text("", size=13, text_align=ft.TextAlign.CENTER)
    nombre = ft.TextField(label="Nombre completo",
                          prefix=ft.Icon(ft.Icons.PERSON_OUTLINE))
    usuario = ft.TextField(label="Usuario",
                           prefix=ft.Icon(ft.Icons.ACCOUNT_CIRCLE_OUTLINED))
    correo = ft.TextField(label="Correo",
                          prefix=ft.Icon(ft.Icons.EMAIL_OUTLINED))
    contrasena = ft.TextField(label="Contraseña", password=True,
                              can_reveal_password=True,
                              prefix=ft.Icon(ft.Icons.LOCK_OUTLINE))
    confirmar = ft.TextField(label="Confirmar contraseña", password=True,
                             can_reveal_password=True,
                             prefix=ft.Icon(ft.Icons.LOCK_RESET))

    def registrar(e):
        n = (nombre.value or "").strip()
        u = (usuario.value or "").strip()
        c = (correo.value or "").strip().lower()
        p = contrasena.value or ""
        pc = confirmar.value or ""

        if len(n) < 3:
            error("El nombre debe tener al menos 3 caracteres.")
            return
        if len(u) < 4 or " " in u:
            error("El usuario debe tener 4 caracteres o más y no usar espacios.")
            return
        if not re.match(r"^[\w.\-]+@[\w.\-]+\.\w+$", c):
            error("Escribe un correo válido.")
            return
        if len(p) < 6:
            error("La contraseña debe tener al menos 6 caracteres.")
            return
        if p != pc:
            error("Las contraseñas no coinciden.")
            return

        ok, respuesta = UsuarioModel.registrar(n, u, c, p)
        if ok:
            mostrar_login()
        else:
            error(respuesta)

    def error(texto):
        mensaje.value = texto
        mensaje.color = "#DC2626"
        page.update()

    confirmar.on_submit = registrar

    return ft.Container(
        expand=True,
        alignment=ft.Alignment.CENTER,
        bgcolor="#F3F4F6",
        padding=25,
        content=ft.Container(
            width=460,
            padding=35,
            bgcolor=ft.Colors.WHITE,
            border_radius=20,
            border=ft.Border.all(1, "#E5E7EB"),
            content=ft.Column(
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=14,
                controls=[
                    ft.Icon(ft.Icons.PERSON_ADD, size=55, color="#2563EB"),
                    ft.Text("Crear cuenta", size=28,
                            weight=ft.FontWeight.BOLD),
                    nombre, usuario, correo, contrasena, confirmar, mensaje,
                    ft.FilledButton(
                        content=ft.Text("Registrarse"),
                        width=360,
                        height=48,
                        on_click=registrar,
                    ),
                    ft.TextButton(
                        content=ft.Text("← Volver al inicio de sesión"),
                        on_click=lambda e: mostrar_login(),
                    ),
                ],
            ),
        ),
    )
