import flet as ft

from models.gasto_model import GastoModel
from models.presupuesto_model import PresupuestoModel


def _tarjeta(titulo, valor, icono):
    return ft.Container(
        width=240,
        height=135,
        padding=20,
        bgcolor=ft.Colors.WHITE,
        border_radius=16,
        border=ft.Border.all(1, "#E5E7EB"),
        content=ft.Column(
            controls=[
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Text(titulo, color="#6B7280"),
                        ft.Icon(icono, color="#2563EB"),
                    ],
                ),
                ft.Text(valor, size=26, weight=ft.FontWeight.BOLD),
            ],
        ),
    )


def dashboard_view(page, usuario_actual):
    uid = usuario_actual["id_usuario"]
    resumen = GastoModel.resumen_mes(uid)
    presupuesto = PresupuestoModel.obtener_actual(uid)
    disponible = presupuesto - resumen["total"]
    ultimos = GastoModel.listar(uid, limite=5)

    filas = []
    for gasto in ultimos:
        filas.append(
            ft.Container(
                padding=12,
                border=ft.Border(bottom=ft.BorderSide(1, "#E5E7EB")),
                content=ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        ft.Column(
                            spacing=1,
                            controls=[
                                ft.Text(gasto["descripcion"],
                                        weight=ft.FontWeight.BOLD),
                                ft.Text(
                                    f'{gasto["categoria"]} · {gasto["fecha"]}',
                                    size=12,
                                    color="#6B7280",
                                ),
                            ],
                        ),
                        ft.Text(
                            f'${float(gasto["monto"]):,.2f}',
                            color="#DC2626",
                            weight=ft.FontWeight.BOLD,
                        ),
                    ],
                ),
            )
        )

    if not filas:
        filas.append(
            ft.Container(
                padding=40,
                alignment=ft.Alignment.CENTER,
                content=ft.Text("Todavía no hay gastos registrados.",
                                color="#6B7280"),
            )
        )

    return ft.Column(
        expand=True,
        scroll=ft.ScrollMode.AUTO,
        controls=[
            ft.Text("Dashboard", size=30, weight=ft.FontWeight.BOLD),
            ft.Text("Resumen del mes actual", color="#6B7280"),
            ft.Row(
                wrap=True,
                spacing=15,
                run_spacing=15,
                controls=[
                    _tarjeta("Total gastado", f'${resumen["total"]:,.2f}',
                             ft.Icons.PAYMENTS),
                    _tarjeta("Presupuesto", f"${presupuesto:,.2f}",
                             ft.Icons.ACCOUNT_BALANCE_WALLET),
                    _tarjeta("Disponible", f"${disponible:,.2f}",
                             ft.Icons.SAVINGS),
                    _tarjeta("Número de gastos", str(resumen["cantidad"]),
                             ft.Icons.RECEIPT_LONG),
                ],
            ),
            ft.Container(
                padding=20,
                bgcolor=ft.Colors.WHITE,
                border_radius=16,
                border=ft.Border.all(1, "#E5E7EB"),
                content=ft.Column(
                    controls=[
                        ft.Text("Últimos gastos", size=20,
                                weight=ft.FontWeight.BOLD),
                        *filas,
                    ],
                ),
            ),
        ],
    )
