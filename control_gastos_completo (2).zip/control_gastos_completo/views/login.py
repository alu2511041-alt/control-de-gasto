import flet as ft

from models.usuario_model import UsuarioModel


def login_view(page, iniciar_aplicacion, mostrar_registro):
    mensaje = ft.Text("", size=13, text_align=ft.TextAlign.CENTER)
    usuario = ft.TextField(
        label="Usuario o correo",
        prefix=ft.Icon(ft.Icons.PERSON_OUTLINE),
        autofocus=True,
    )
    contrasena = ft.TextField(
        label="Contraseña",
        prefix=ft.Icon(ft.Icons.LOCK_OUTLINE),
        password=True,
        can_reveal_password=True,
    )

    def ingresar(e):
        identificador = (usuario.value or "").strip()
        clave = contrasena.value or ""
        if not identificador or not clave:
            mensaje.value = "Completa usuario y contraseña."
            mensaje.color = "#DC2626"
            page.update()
            return

        ok, respuesta, datos = UsuarioModel.iniciar_sesion(identificador, clave)
        if ok:
            iniciar_aplicacion(datos)
        else:
            mensaje.value = respuesta
            mensaje.color = "#DC2626"
            page.update()

    contrasena.on_submit = ingresar

    return ft.Container(
        expand=True,
        alignment=ft.Alignment.CENTER,
        bgcolor="#F3F4F6",
        padding=25,
        content=ft.Container(
            width=440,
            padding=35,
            bgcolor=ft.Colors.WHITE,
            border_radius=20,
            border=ft.Border.all(1, "#E5E7EB"),
            content=ft.Column(
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=16,
                controls=[
                    ft.Icon(ft.Icons.ACCOUNT_BALANCE_WALLET,
                            size=60, color="#2563EB"),
                    ft.Text("Control de Gastos", size=28,
                            weight=ft.FontWeight.BOLD),
                    ft.Text("Inicia sesión para continuar", color="#6B7280"),
                    usuario,
                    contrasena,
                    mensaje,
                    ft.FilledButton(
                        content=ft.Text("Iniciar sesión"),
                        width=360,
                        height=48,
                        on_click=ingresar,
                    ),
                    ft.TextButton(
                        content=ft.Text("Crear una cuenta"),
                        on_click=lambda e: mostrar_registro(),
                    ),
                ],
            ),
        ),
    )
