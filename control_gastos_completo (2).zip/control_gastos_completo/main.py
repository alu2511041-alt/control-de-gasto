import flet as ft

from components.sidebar import Sidebar
from database.conexion import ConexionBD
from views.dashboard import dashboard_view
from views.gastos import gastos_view
from views.login import login_view
from views.presupuesto import presupuesto_view
from views.registro import registro_view
from views.reportes import reportes_view


def main(page: ft.Page):
    page.title = "Control de Gastos"
    page.padding = 0
    page.bgcolor = "#F3F4F6"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.window.width = 1300
    page.window.height = 780
    page.window.min_width = 900
    page.window.min_height = 600

    usuario_actual = {"datos": None}

    def limpiar():
        page.clean()

    def hay_conexion():
        conexion = ConexionBD.conectar()
        if conexion is None:
            return False
        conexion.close()
        return True

    def mostrar_login():
        if not hay_conexion():
            limpiar()
            page.add(
                ft.Container(
                    expand=True,
                    alignment=ft.Alignment.CENTER,
                    content=ft.Text(
                        "No se pudo conectar con MySQL. Revisa XAMPP y config.py.",
                        size=20,
                        color="#DC2626",
                    ),
                )
            )
            return

        usuario_actual["datos"] = None
        limpiar()
        page.add(
            login_view(
                page,
                iniciar_aplicacion=mostrar_aplicacion,
                mostrar_registro=mostrar_registro,
            )
        )

    def mostrar_registro():
        limpiar()
        page.add(registro_view(page, mostrar_login))

    def cerrar_sesion():
        mostrar_login()

    def mostrar_aplicacion(datos_usuario):
        usuario_actual["datos"] = datos_usuario
        limpiar()

        contenido = ft.Container(expand=True, padding=30)
        titulo = ft.Text("Dashboard", size=18, weight=ft.FontWeight.BOLD)

        nombres = {
            "dashboard": "Dashboard",
            "gastos": "Gastos",
            "presupuesto": "Presupuesto",
            "reportes": "Reportes",
        }

        def cambiar_vista(nombre):
            titulo.value = nombres.get(nombre, "Control de Gastos")
            if nombre == "dashboard":
                contenido.content = dashboard_view(page, datos_usuario)
            elif nombre == "gastos":
                contenido.content = gastos_view(
                    page, datos_usuario, cambiar_vista
                )
            elif nombre == "presupuesto":
                contenido.content = presupuesto_view(
                    page, datos_usuario, cambiar_vista
                )
            elif nombre == "reportes":
                contenido.content = reportes_view(page, datos_usuario)
            page.update()

        sidebar = Sidebar(
            cambiar_vista,
            cerrar_sesion,
            datos_usuario.get("nombre", "Usuario"),
        )

        barra = ft.Container(
            height=70,
            bgcolor=ft.Colors.WHITE,
            padding=ft.Padding.symmetric(horizontal=30, vertical=15),
            border=ft.Border(
                bottom=ft.BorderSide(1, "#E5E7EB")
            ),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    titulo,
                    ft.Text(
                        datos_usuario.get("nombre", "Usuario"),
                        weight=ft.FontWeight.BOLD,
                    ),
                ],
            ),
        )

        page.add(
            ft.Row(
                expand=True,
                spacing=0,
                controls=[
                    sidebar,
                    ft.Column(
                        expand=True,
                        spacing=0,
                        controls=[barra, contenido],
                    ),
                ],
            )
        )
        cambiar_vista("dashboard")

    mostrar_login()


if __name__ == "__main__":
    ft.run(main)
