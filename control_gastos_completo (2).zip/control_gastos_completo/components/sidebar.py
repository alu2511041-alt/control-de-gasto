import flet as ft


class Sidebar(ft.Container):
    def __init__(self, cambiar_vista, cerrar_sesion, nombre_usuario="Usuario"):
        super().__init__()
        self.cambiar_vista = cambiar_vista
        self.cerrar_sesion = cerrar_sesion
        self.width = 245
        self.bgcolor = "#111827"
        self.padding = 20
        self.botones = {}

        inicial = nombre_usuario[0].upper() if nombre_usuario else "U"

        self.content = ft.Column(
            expand=True,
            spacing=8,
            controls=[
                ft.Row(
                    controls=[
                        ft.Container(
                            width=48,
                            height=48,
                            alignment=ft.Alignment.CENTER,
                            bgcolor="#2563EB",
                            border_radius=12,
                            content=ft.Icon(
                                ft.Icons.ACCOUNT_BALANCE_WALLET,
                                color=ft.Colors.WHITE,
                                size=27,
                            ),
                        ),
                        ft.Column(
                            spacing=0,
                            controls=[
                                ft.Text("Control", color=ft.Colors.WHITE, size=20,
                                        weight=ft.FontWeight.BOLD),
                                ft.Text("de Gastos", color="#93C5FD", size=14),
                            ],
                        ),
                    ],
                ),
                ft.Divider(height=35, color="#374151"),
                self._boton("dashboard", "Dashboard", ft.Icons.DASHBOARD),
                self._boton("gastos", "Gastos", ft.Icons.PAYMENTS),
                self._boton("presupuesto", "Presupuesto",
                            ft.Icons.ACCOUNT_BALANCE_WALLET),
                self._boton("reportes", "Reportes", ft.Icons.BAR_CHART),
                ft.Container(expand=True),
                ft.Divider(color="#374151"),
                ft.Row(
                    controls=[
                        ft.CircleAvatar(
                            bgcolor="#2563EB",
                            content=ft.Text(inicial, color=ft.Colors.WHITE,
                                            weight=ft.FontWeight.BOLD),
                        ),
                        ft.Text(
                            nombre_usuario,
                            expand=True,
                            color=ft.Colors.WHITE,
                            weight=ft.FontWeight.BOLD,
                            overflow=ft.TextOverflow.ELLIPSIS,
                        ),
                    ],
                ),
                ft.Container(
                    height=48,
                    border_radius=10,
                    padding=ft.Padding.symmetric(horizontal=14, vertical=8),
                    on_click=lambda e: self.cerrar_sesion(),
                    content=ft.Row(
                        controls=[
                            ft.Icon(ft.Icons.LOGOUT, color="#F87171"),
                            ft.Text("Cerrar sesión", color="#FCA5A5"),
                        ],
                    ),
                ),
            ],
        )
        self.seleccionar("dashboard")

    def _boton(self, clave, texto, icono):
        boton = ft.Container(
            height=52,
            border_radius=10,
            padding=ft.Padding.symmetric(horizontal=14, vertical=10),
            on_click=lambda e, nombre=clave: self._abrir(nombre),
            content=ft.Row(
                controls=[
                    ft.Icon(icono, size=22, color="#9CA3AF"),
                    ft.Text(texto, size=15, color="#D1D5DB"),
                ],
            ),
        )
        self.botones[clave] = boton
        return boton

    def _abrir(self, nombre):
        self.seleccionar(nombre)
        self.cambiar_vista(nombre)

    def seleccionar(self, seleccionado):
        for nombre, boton in self.botones.items():
            activo = nombre == seleccionado
            boton.bgcolor = "#2563EB" if activo else ft.Colors.TRANSPARENT
            boton.content.controls[0].color = ft.Colors.WHITE if activo else "#9CA3AF"
            boton.content.controls[1].color = ft.Colors.WHITE if activo else "#D1D5DB"
